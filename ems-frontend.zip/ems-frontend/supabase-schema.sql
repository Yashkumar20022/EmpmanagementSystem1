-- Run this in Supabase SQL Editor (Project > SQL Editor > New query)

-- 0. Sequence + auto ID generator (produces EMP0001, EMP0002, ...)
create sequence if not exists employee_id_seq start 1;

create or replace function generate_employee_id()
returns text
language sql
as $$
  select 'EMP' || lpad(nextval('employee_id_seq')::text, 4, '0');
$$;

-- 1. Employees table (holds profile + role for every logged-in user)
create table if not exists employees (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique references auth.users(id) on delete cascade,
  employee_id text unique default generate_employee_id(),
  full_name text not null,
  email text unique not null,
  phone text,
  department text,
  designation text,
  salary numeric,
  joining_date date,
  address text,
  role text not null default 'employee' check (role in ('admin', 'employee')),
  created_at timestamptz default now()
);

-- 2. Enable Row Level Security
alter table employees enable row level security;

-- 3. Helper function: is the current user an admin?
create or replace function is_admin()
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1 from employees
    where user_id = auth.uid() and role = 'admin'
  );
$$;

-- 4. Policies
-- Everyone logged in can read their own row
create policy "read own profile"
on employees for select
using (user_id = auth.uid());

-- Admins can read every row
create policy "admin reads all"
on employees for select
using (is_admin());

-- Only admins can insert new employees
create policy "admin inserts"
on employees for insert
with check (is_admin());

-- Only admins can update any row (employees cannot self-edit sensitive fields)
create policy "admin updates"
on employees for update
using (is_admin());

-- Only admins can delete
create policy "admin deletes"
on employees for delete
using (is_admin());

-- 5. IMPORTANT — creating your first admin:
-- Step A: In Supabase Dashboard > Authentication > Users, create a user
--         (e.g. admin@yourcompany.com) with a password.
-- Step B: Copy that user's UUID, then run:
--
-- insert into employees (user_id, full_name, email, role, department, designation)
-- values ('PASTE-USER-UUID-HERE', 'Admin Name', 'admin@yourcompany.com', 'admin', 'Management', 'HR Admin');
--
-- After that, the admin can add more employees directly from the app UI —
-- but each new employee also needs a matching Supabase Auth user (Dashboard
-- > Authentication > Users > Add user) with the SAME email, so they can log in.
