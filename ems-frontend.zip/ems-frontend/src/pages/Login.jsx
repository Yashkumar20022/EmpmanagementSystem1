import { useState } from 'react'
import { useAuth } from '../context/AuthContext'

export default function Login() {
  const { login } = useAuth()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setBusy(true)
    const { error } = await login(email, password)
    setBusy(false)
    if (error) setError(error.message)
  }

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-canvas px-4">
      <div className="w-full max-w-sm animate-in">
        <div className="text-center mb-8">
          <div className="w-12 h-12 rounded-2xl bg-violet mx-auto mb-4 flex items-center justify-center font-display font-bold text-white text-lg">
            E
          </div>
          <h1 className="font-display text-2xl font-bold">Welcome back</h1>
          <p className="text-sm text-ink/60 mt-1">Sign in to your EMS account</p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="bg-surface border border-line rounded-2xl p-6 shadow-sm shadow-violet/5"
        >
          {error && (
            <div className="mb-4 text-sm bg-rose/10 text-rose border border-rose/20 rounded-lg px-3 py-2">
              {error}
            </div>
          )}

          <label className="block text-xs font-medium text-ink/60 mb-1">Email</label>
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@company.com"
            className="w-full mb-4 rounded-lg border border-line px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-violet/40 focus:border-violet transition"
          />

          <label className="block text-xs font-medium text-ink/60 mb-1">Password</label>
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••"
            className="w-full mb-6 rounded-lg border border-line px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-violet/40 focus:border-violet transition"
          />

          <button
            type="submit"
            disabled={busy}
            className="w-full bg-violet hover:bg-violet-dark text-white font-medium text-sm rounded-lg py-2.5 transition disabled:opacity-60"
          >
            {busy ? 'Signing in…' : 'Sign in'}
          </button>
        </form>

        <p className="text-center text-xs text-ink/40 mt-6">
          Accounts are created by your admin. Contact HR if you need access.
        </p>
      </div>
    </div>
  )
}
